function f = ws_approach( lamda,f,i )
%ws_approach
f=lamda(i,:)*f';


end

